import db from "#db"

const cleanJid = (jid) => (typeof jid === 'string' ? jid.replace(/:\d+@/, '@') : '')

export default {
  command: ['cf', 'flip', 'coinflip'],
  category: 'rpg',
  run: async ({ msg, sock, args, command, text, usedPrefix: prefix }) => {
    const sender = cleanJid(msg.sender)
    const chat = await db.getChat(msg.chat)
    const user = await db.getChatUser(msg.chat, sender)
    const botId = cleanJid(sock.user?.id || '')
    const botSettings = await db.getSettings(botId)
    const monedas = botSettings?.currency || 'monedas'

    if (chat?.adminonly || !chat?.rpg)
      return msg.reply(mess.comandooff)

    const cantidad = parseInt(args[0])
    const eleccion = args[1]?.toLowerCase()

    if (!eleccion || isNaN(cantidad)) {
      return msg.reply(
        `✎ Elige una opción ( *Cara o Cruz* ) y la cantidad a apostar, para lanzar la moneda.\n\n\`Ejemplo\`\n> *${prefix + command}* 2000 cara`,
      )
    }

    if (!['cara', 'cruz'].includes(eleccion)) {
      return msg.reply(
        `「✿」 Elección no válida. Por favor, elige cara o cruz.`,
      )
    }

    if (cantidad <= 199) {
      return msg.reply(
        `《✤》 Por favor, elige una cantidad mayor a 200 ${monedas} para apostar.`,
      )
    }

    if ((user.coins || 0) < cantidad) {
      return msg.reply(`《✤》 No tienes suficientes *${monedas}* para apostar.`)
    }

    const resultado = Math.random() < 0.5 ? 'cara' : 'cruz'
    const cantidadFormatted = cantidad.toLocaleString()
    let mensaje = `ꕥ La moneda ha caído en *${resultado}*.\n`

    if (resultado === eleccion) {
      user.coins += cantidad
      await db.updateChatUser(msg.chat, sender, 'coins', user.coins)
      mensaje += `¡Has ganado *¥${cantidadFormatted} ${monedas}*!`
    } else {
      user.coins -= cantidad
      await db.updateChatUser(msg.chat, sender, 'coins', user.coins)
      mensaje += `Has perdido *¥${cantidadFormatted} ${monedas}*.`
    }

    await sock.reply(msg.chat, mensaje, msg)
  },
};