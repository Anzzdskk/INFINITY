import db from "#db"

const cleanJid = (jid) => (typeof jid === 'string' ? jid.replace(/:\d+@/, '@') : '')

export default {
  command: ['topcount', 'topmensajes', 'topmsgcount', 'topmessages'],
  category: 'rpg',
  run: async ({ msg, sock, args, command, text, usedPrefix: prefix }) => {
    try {
      const chatId = msg.chat
      const chatData = await db.getChat(chatId)
      const chatDatas = await db.getChatUser(chatId)

      if (chatData?.adminonly || !chatData?.rpg)
        return msg.reply(mess.comandooff)

      const now = new Date()
      const cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

      const ranking = (chatDatas || [])
        .map(user => {
          const stats = user.stats || {}
          const days = Object.entries(stats).filter(([date]) => new Date(date) >= cutoff)

          const totalMsgs = days.reduce((acc, [, d]) => acc + (d.msgs || 0), 0)
          const totalCmds = days.reduce((acc, [, d]) => acc + (d.cmds || 0), 0)

          return { jid: cleanJid(user.user_id || user.jid), totalMsgs, totalCmds }
        })
        .filter(u => u.totalMsgs > 0)
        .sort((a, b) => b.totalMsgs - a.totalMsgs)

      if (ranking.length === 0)
        return msg.reply(`「✎」 No hay actividad registrada en los últimos 30 días.`)

      const page = parseInt(args[0]) || 1
      const perPage = 10
      const totalPages = Math.ceil(ranking.length / perPage)

      if (page < 1 || page > totalPages)
        return msg.reply(`「✎」 Página inválida. Solo hay ${totalPages} páginas disponibles.`)

      const start = (page - 1) * perPage
      const end = start + perPage
      const pageRanking = ranking.slice(start, end)

      let report = `❀ Top de mensajes en los últimos *30* días\n\n`

      for (let i = 0; i < pageRanking.length; i++) {
        const u = pageRanking[i]
        const na = await db.getUser(u.jid) || {}
        const name = na.name || u.jid.split('@')[0] || 'Usuario'
        report += `*${start + i + 1}.* ${name}\n`
        report += `   » Mensajes: \`${u.totalMsgs}\`, Comandos: \`${u.totalCmds}\`\n`
      }

      if (page < totalPages) {
        report += `\n> Para ver la siguiente página › *${prefix + command} ${page + 1}*`
      }

      await sock.reply(chatId, report, msg)
    } catch (e) {
      await msg.reply(msgglobal)
    }
  }
}