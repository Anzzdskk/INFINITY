import db from "#db"

const cleanJid = (jid) => (typeof jid === 'string' ? jid.replace(/:\d+@/, '@') : '')

export default {
  command: ['waittimes', 'cooldowns', 'economyinfo', 'einfo'],
  category: 'rpg',
  run: async ({ msg, sock }) => {
    const sender = cleanJid(msg.sender)
    const chatId = msg.chat
    const botId = cleanJid(sock.user?.id || '')
    const botSettings = await db.getSettings(botId)
    const chatData = await db.getChat(chatId)

    if (chatData?.adminonly || !chatData?.rpg)
      return msg.reply(mess.comandooff)

    const user = await db.getChatUser(chatId, sender)
    const user2 = await db.getUser(sender)
    const now = Date.now()
    const oneDay = 24 * 60 * 60 * 1000

    const cooldowns = {
      work: Math.max(0, (user.workCooldown || 0) - now),
      slut: Math.max(0, (user.slutCooldown || 0) - now),
      crime: Math.max(0, (user.crimeCooldown || 0) - now),
      daily: Math.max(0, (user.lastDaily || 0) + oneDay - now),
      mine: Math.max(0, (user.mineCooldown || 0) - now),
      ritual: Math.max(0, (user.ritualCooldown || 0) - now),
      rt: Math.max(0, (user.rtCooldown || 0) - now),
      steal: Math.max(0, (user.roboCooldown || 0) - now),
      slot: Math.max(0, (user.lastslot || 0) - now),
      fish: Math.max(0, (user.lastfish || 0) - now),
      dungeon: Math.max(0, (user.lastdungeon || 0) - now),
      hunt: Math.max(0, (user.lasthunt || 0) - now),
      ppt: Math.max(0, (user.pptCooldown || 0) - now),
      weekly: Math.max(0, (user.lastWeekly || 0) + 7 * oneDay - now),
      monthly: Math.max(0, (user.lastMonthly || 0) + 30 * oneDay - now)
    }

    const coins = user.coins || 0
    const currency = botSettings?.currency || 'monedas'
    const name = user2?.name || msg.pushName || sender.split('@')[0]

    const mensaje = `ׅ  ׄ  ꕤ   ׅ り Usuario \`<${name}>\`

𖹭᳔ㅤㅤㅤׄㅤㅤ❀ㅤㅤׅㅤㅤゕㅤㅤׄㅤㅤㅤ𑄾𑄾

ׅ  ׄ  ✿   ׅ り Work » *${formatTime(cooldowns.work)}*
ׅ  ׄ  ✿   ׅ り Slut » *${formatTime(cooldowns.slut)}*
ׅ  ׄ  ✿   ׅ り Crime » *${formatTime(cooldowns.crime)}*
ׅ  ׄ  ✿   ׅ り Daily » *${formatTime(cooldowns.daily)}*
ׅ  ׄ  ✿   ׅ り Mine » *${formatTime(cooldowns.mine)}*
ׅ  ׄ  ✿   ׅ り Ritual » *${formatTime(cooldowns.ritual)}*
ׅ  ׄ  ✿   ׅ り Ruleta » *${formatTime(cooldowns.rt)}*
ׅ  ׄ  ✿   ׅ り Steal » *${formatTime(cooldowns.steal)}*
ׅ  ׄ  ✿   ׅ り Slot » *${formatTime(cooldowns.slot)}*
ׅ  ׄ  ✿   ׅ り Fish » *${formatTime(cooldowns.fish)}*
ׅ  ׄ  ✿   ׅ り Dungeon » *${formatTime(cooldowns.dungeon)}*
ׅ  ׄ  ✿   ׅ り Hunt » *${formatTime(cooldowns.hunt)}*
ׅ  ׄ  ✿   ׅ り Ppt » *${formatTime(cooldowns.ppt)}*

𖹭᳔ㅤㅤㅤׄㅤㅤꕤㅤㅤׅㅤㅤゕㅤㅤׄㅤㅤㅤ𑄾𑄾

ׅ  ׄ  ⛁   ׅ り Coins totales » ¥${coins.toLocaleString()} ${currency}`

    await msg.reply(mensaje)
  }
}

function formatTime(ms) {
  if (ms <= 0) return 'Ahora.'
  const totalSeconds = Math.floor(ms / 1000)
  const days = Math.floor(totalSeconds / 86400)
  const hours = Math.floor((totalSeconds % 86400) / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const seconds = totalSeconds % 60

  const parts = []
  if (days > 0) parts.push(`${days} d`)
  if (hours > 0) parts.push(`${hours} h`)
  if (minutes > 0) parts.push(`${minutes} m`)
  if (seconds > 0) parts.push(`${seconds} s`)
  return parts.length ? parts.join(', ') : 'Ahora.'
}