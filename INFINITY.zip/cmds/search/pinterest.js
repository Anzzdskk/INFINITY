import axios from "axios"

export default {
  command: ["pinterest", "pin"],
  category: "search",
  run: async ({ msg, sock, args, from }) => {
    const text = args.join(" ")
    const isPinterestUrl = /^https?:\/\//.test(text)

    if (!text) {
      return msg.reply(
        `✿ Ingresa un *término* de búsqueda o un enlace de *Pinterest*.`
      )
    }

    try {
      if (isPinterestUrl) {
        const pinterestUrl = `${api.url}/dl/pinterest?url=${text}&key=${api.key}`
        const ress = await axios.get(pinterestUrl)
        const { data: result } = ress.data
        const mediaType = ["image", "video"].includes(result.type) ? result.type : "document"

        await sock.sendMessage(
          msg.chat,
          { [mediaType]: { url: result.dl }, caption: null },
          { quoted: msg }
        )
      } else {
        const pinterestAPI = `${api.url}/search/pinterest?query=${text}&key=${api.key}`
        const res = await axios.get(pinterestAPI)
        const jsons = res.data
        const results = jsons.data

        if (!results || results.length === 0) {
          return msg.reply(`✿ No se encontraron resultados para *${text}*`)
        }

        const medias = []
        for (const result of results.slice(0, 10)) {
          const caption =
            `ꕥ ꨩᰰ𑪐𑂺 ˳ ׄ 𝖯𝗂𝗇𝗍𝖾𝗋𝖾𝗌𝗍 𝖲𝖾𝖺𝗋𝖼𝗁 ࣭𑁯ᰍ   ̊ ܃܃\n\n` +
            `${result.title ? `𖣣ֶㅤ֯⌗ ✿ ⬭ Título › *${result.title}*\n` : ""}` +
            `${result.description ? `𖣣ֶㅤ֯⌗ ❀ ⬭ Descripción › *${result.description}*\n` : ""}` +
            `${result.full_name ? `𖣣ֶㅤ֯⌗ ❑ ⬭ Autor › *${result.full_name}*\n` : ""}` +
            `${result.likes ? `𖣣ֶㅤ֯⌗ ♡ ⬭ Likes › *${result.likes}*\n` : ""}` +
            `${result.created ? `𖣣ֶㅤ֯⌗ ✤ ⬭ Publicado › *${result.created}*` : ""}`

          medias.push({
            type: "image",
            data: { url: result.hd || result.url },
            caption
          })
        }

        if (medias.length) {
          await sock.sendAlbumMessage(msg.chat, medias, { quoted: msg })
        } else {
          await msg.reply(`✿ No se pudieron procesar los resultados.`)
        }
      }
    } catch (e) {
      await sock.reply(
        msg.chat,
        msgglobal,
        msg
      )
    }
  },
}