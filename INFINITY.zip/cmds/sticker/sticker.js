import db from "#db"
import fs from 'fs'
import fetch from 'node-fetch'
import exif from '../../lib/exif.js'
const { writeExif } = exif

export default {
  command: ['sticker', 's'],
  category: 'stickers',
  run: async ({ msg, sock, args, command, text, usedPrefix: prefix }) => {
    try {
      const quoted = msg.quoted ? msg.quoted : msg
      const mime = (quoted.msg || quoted).mimetype || ''
      let user = await db.getUser(msg.sender)
      const name = user.name
      let texto1 = user.metadatos || `˚₊· ͟͟͞͞➳ ᴜsᴇʀ :: @${name}\n`
      let texto2 = user.metadatos2 || `·˚｡˚.𑁍͟͟͞͞꒰˚ɪɴғɪɴɪᴛʏ - ᴡᴀ - ʙᴏᴛ·—̳͟͞͞♡\n𓉘ʙʏ - ᴀɴᴢᴢ𓉝 \n+58 426 895 5896`

      let marca = args.join(' ').trim().split(/[\u2022|]/).map(part => part.trim())
      let pack = marca[0] || texto1
      let author = marca.length > 1 ? marca[1] : texto2

      if (/image/.test(mime) || /webp/.test(mime)) {
        let buffer = await quoted.download()
        const media = { mimetype: mime, data: buffer }
        const metadata = { packname: pack, author: author, categories: [''] }
        const stickerPath = await writeExif(media, metadata)
        await sock.sendMessage(msg.chat, { sticker: { url: stickerPath }}, { quoted: msg })
        fs.unlinkSync(stickerPath)
      } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 20) return msg.reply('> 🍁_El video no puede ser muy largo_')
        let buffer = await quoted.download()
        const tmpFile = `./lib/system/tmp/video-${Date.now()}.mp4`
        fs.writeFileSync(tmpFile, buffer)
        await sock.sendVideoAsSticker(msg.chat, tmpFile, msg, { packname: pack, author: author })
        fs.unlinkSync(tmpFile)
      } else if (args[0] && isUrl(args[0])) {
        const url = args[0]
        const res = await fetch(url)
        if (!res.ok) return msg.reply('❖ No pude descargar ese archivo desde la URL.')
        const buffer = Buffer.from(await res.arrayBuffer())
        const media = { mimetype: 'image/webp', data: buffer }
        const metadata = { packname: pack, author: author, categories: [''] }
        const stickerPath = await writeExif(media, metadata)
        await sock.sendMessage(msg.chat, { sticker: { url: stickerPath }}, { quoted: msg })
        fs.unlinkSync(stickerPath)
      } else {
        return sock.reply(msg.chat, `> _·˚Envía o responde a una imagen/video/gif/url para hacer Tu sticker_`, msg)
      }
    } catch (e) {
      return msg.reply(msgglobal)
    }
  }
}

const isUrl = (text) => {
  return /^https?:\/\/.+/i.test(text)
}